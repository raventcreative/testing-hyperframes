| File | Codec | Profile | Pixel fmt | Size | FPS | Duration (s) | Frames | Streams | Audio streams | Plays (full decode) | BG deviation from #00FF00 | Non-green px frame 0 | Result |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 01_STEP_1_RESI_FLOATING_3D.mp4 | h264 | High | yuv420p | 1080x1080 | 60 | 7.000 | 420 | 1 | 0 | yes | ±1 | 0 | PASS |
| 02_STEP_1_REKENING_KORAN_FLOATING_3D.mp4 | h264 | High | yuv420p | 1080x1080 | 60 | 7.000 | 420 | 1 | 0 | yes | ±1 | 0 | PASS |
| 03_STEP_2_DOKUMEN_MENJADI_LAPORAN_KEUANGAN.mp4 | h264 | High | yuv420p | 1080x1080 | 60 | 11.000 | 660 | 1 | 0 | yes | ±1 | 0 | PASS |

ALL CHECKS PASSED
